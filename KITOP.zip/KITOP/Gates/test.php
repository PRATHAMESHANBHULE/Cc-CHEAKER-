<?php

////API Edited By: @CODE_WRAITH
////Rest API
///Enjoy_xD..!!!

echo "Select Atleast 1 Gate For Hits";

#-------------[The End]-------------#

?>
